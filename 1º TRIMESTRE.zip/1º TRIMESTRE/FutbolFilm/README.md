# FutbolFilm — Proyecto PHP MVC de DWES

## Instrucciones de instalación
Para desplegar el proyecto en casa, seguir los siguientes pasos:
1. Clonar el repositorio y abrirlo con PHPStorm.
2. Copiar el .env.example renombrarlo a .env
3. Rellenar las variables con los datos de vuestro usuario.
   4. Para conocer el UID y GID del usuario ejecutar el comando `id`
4. Lanzar el docker-compose con el botón derecho ejecutar.
5. Entra en la terminal del contenedor de PHP dentro del apartado de servicios de PHPStorm. 
6. Ejecuta el comando `composer install` para que se instalen las librerias del proyecto. 