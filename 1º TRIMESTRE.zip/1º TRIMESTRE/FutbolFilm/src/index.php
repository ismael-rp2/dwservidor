<?php

require_once __DIR__ . '/vendor/autoload.php';

use Phroute\Phroute\RouteCollector;
use Phroute\Phroute\Dispatcher;
use Phroute\Phroute\Exception\HttpRouteNotFoundException;
use Phroute\Phroute\Exception\HttpMethodNotAllowedException;

//Ejercicio 5
use \Ismael\FutbolFilm\Class\Partido;
use \Ismael\FutbolFilm\Class\Contenido;

//Ejercicio 6
use Ismael\FutbolFilm\Class\Aficionado;

//Ejercicio 7
use Ismael\FutbolFilm\Controllers\AficionadoController;

session_start();

$router = new RouteCollector();

// Ruta de prueba inicial
$router->get('/', function () {
    return "<h1>¡Hola! Entorno de práctica PHP listo</h1>";
});

// Ruta de prueba para Postman (JSON)
$router->get('/api/test', function () {
    header('Content-Type: application/json');
    return json_encode([
        'ok' => true,
        'mensaje' => 'API funcionando correctamente'
    ]);
});


// Prueba Ejercicio 5 -> http://localhost:8080/ej5
$router->get('/ej5', function () {
    $p1 = new Partido();
    $p1->setTitulo("Eldense vs Elche")
        ->setAnio(2026)
        ->setEstadio("Nuevo Pepico Amat")
        ->setResultado("2-1");

    return $p1->resumen();
});


// Prueba Ejercicio 6 -> http://localhost:8080/ej6
$router->get('/ej6', function () {
    header('Content-Type: application/json');
    $datosPost = [
        'id' => 10,
        'nombre' => 'Carlos',
        'email' => 'carlos@eldense.es',
        'password' => 'secreto123'
    ];
    $aficionado = Aficionado::createFromArray($datosPost);
    return json_encode($aficionado, JSON_PRETTY_PRINT);
});


//Ejercicio de repaso AficionadoController
// Ejercicio de repaso AficionadoController
$router->get('/aficionado', [AficionadoController::class, 'index']);
$router->get('/aficionado/{id}', [AficionadoController::class, 'show']);
$router->post('/aficionado', [AficionadoController::class, 'store']);
$router->put('/aficionado/{id}', [AficionadoController::class, 'update']);
$router->delete('/aficionado/{id}', [AficionadoController::class, 'destroy']);

//Dispatcher
$dispatcher = new Dispatcher($router->getData());

try {
    $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $response = $dispatcher->dispatch($_SERVER['REQUEST_METHOD'], $url);
    echo $response;

} catch (HttpRouteNotFoundException $e) {
    http_response_code(404);
    echo "<h1>Error 404</h1><p>Ruta no encontrada.</p>";
} catch (HttpMethodNotAllowedException $e) {
    http_response_code(405);
    echo "<h1>Error 405</h1><p>Método HTTP no permitido.</p>";
}




