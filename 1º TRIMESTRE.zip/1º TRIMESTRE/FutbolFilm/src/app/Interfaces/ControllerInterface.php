<?php

namespace Ismael\FutbolFilm\Interfaces;

interface ControllerInterface {

    public function index();

    public function show(int $id);

    public function create();

    public function store();

    public function edit(int $id);

    public function update(int $id);

    public function destroy(int $id);


}