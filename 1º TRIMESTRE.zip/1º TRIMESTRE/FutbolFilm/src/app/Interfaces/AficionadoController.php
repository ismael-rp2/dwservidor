<?php

namespace Ismael\FutbolFilm\Interfaces;

use Ismael\FutbolFilm\Interfaces\ControllerInterface;

class AficionadoController implements ControllerInterface
{

    private function jsonResponse(array $data, int $statusCode = 200):void{
        header('Content-Tye: application\json; charset=utf-8');
        http_response_code($statusCode);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    public function index()
    {
        // TODO: Implement index() method.
        $this->jsonResponse([
            'status' => 'success',
            'message' => 'Se muestran todos los aficionados'
        ], 200);
    }

    public function show(int $id)
    {
        // TODO: Implement show() method.
        $this->jsonResponse([
            'status' => 'success',
            "message" => "Datos del aficionado {$id}"
        ],200);
    }

    public function create()
    {
        // TODO: Implement create() method.
    }

    public function store()
    {
        // TODO: Implement store() method.

    }

    public function edit(int $id)
    {
        // TODO: Implement edit() method.
    }

    public function update(int $id)
    {
        // TODO: Implement update() method.
    }

    public function destroy(int $id)
    {
        // TODO: Implement destroy() method.
    }
}