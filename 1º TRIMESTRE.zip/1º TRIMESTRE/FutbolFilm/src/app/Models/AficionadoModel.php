<?php

namespace Ismael\FutbolFilm\Models;

class AficionadoModel {

    private static function conectar(): PDO{
        $datos = setAttrib
    }

}