<?php

namespace Ismael\FutbolFilm\Controllers;

use Ismael\FutbolFilm\Class\Aficionado;
use Ismael\FutbolFilm\Interfaces\ControllerInterface;

class AficionadoController implements ControllerInterface
{

    private function jsonResponse(array $data, int $statusCode = 200):void{
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($statusCode);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    public function index()
    {
        // TODO: Implement index() method.
        $this->jsonResponse([
            'status' => 'success',
            'message' => 'Se muestran todos los aficionados'
        ], 200);
    }

    public function show(int $id)
    {
        // TODO: Implement show() method.
        $this->jsonResponse([
            'status' => 'success',
            "message" => "Datos del aficionado {$id}"
        ],200);
    }

    public function create()
    {
        // TODO: Implement create() method.
    }

    public function store() {
        if(!isset($_POST['id'], $_POST['nombre'], $_POST['email'], $_POST['password'])){
            $this->jsonResponse([
                'status' => 'error',
                "message" => 'Faltan datos obligatorios'
            ], 400);
            return;
        }

        $aficionado = Aficionado::createFromArray($_POST);

        $this->jsonResponse([
            'status' => 'success',
            'message' => $aficionado
        ], 201);
    }

    public function edit(int $id)
    {
        // TODO: Implement edit() method.
    }

    public function update(int $id)
    {
        $leerJSON = file_get_contents('php://input');
        $datos = json_decode($leerJSON, true);

        $this->jsonResponse([
            'id' => $id,
            'datos' => $datos
        ], 200);
    }

    public function destroy(int $id)
    {
        $this->jsonResponse([
            'status' => 'success',
            "message" => "Aficionado con {$id} eliminado"
        ],200);
    }
}