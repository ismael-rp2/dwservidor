<?php

namespace Ismael\FutbolFilm\Class;
use JsonSerializable;

class Aficionado implements JsonSerializable{

    // PROPIEDADES
    private int $id;
    private string $nombre;
    private string $email;
    private string $password;


    //CONSTRUCTOR

    /**
     * @param int $id
     * @param string $nombre
     * @param string $email
     * @param string $password
     */
    public function __construct(int $id, string $nombre, string $email, string $password)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email = $email;
        $this->password = $password;
    }

    //Mét0do Estático
    public static function createFromArray(array $data): self{
        return new self(
            (int) $data['id'],
            $data['nombre'],
            $data['email'],
            $data['password']
        );
    }


    /**
     * @inheritDoc
     */
    public function jsonSerialize(): mixed {
        return [
            'id'     => $this->id,
            'nombre' => $this->nombre,
            'email'  => $this->email
        ];
    }

}