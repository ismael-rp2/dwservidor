<?php

namespace Ismael\FutbolFilm\Class;
use JsonSerializable;

class Aficionado implements JsonSerializable{

    // PROPIEDADES
    private int $id;
    private string $nombre;
    private string $email;
    private string $password;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): void
    {
        $this->nombre = $nombre;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    //GETTER Y SETTER



    //CONSTRUCTOR

    /**
     * @param int $id
     * @param string $nombre
     * @param string $email
     * @param string $password
     */
    public function __construct(int $id, string $nombre, string $email, string $password)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email = $email;
        $this->password = $password;
    }

    //Mét0do Estático
    public static function createFromArray(array $data): self{
        return new self(
            (int) $data['id'] ?? 0,
            $data['nombre'],
            $data['email'],
            $data['password']
        );
    }


    /**
     * @inheritDoc
     */
    public function jsonSerialize(): mixed {
        return [
            'id'     => $this->id,
            'nombre' => $this->nombre,
            'email'  => $this->email
        ];
    }

}