<?php

namespace Ismael\FutbolFilm\Class;

use Ismael\FutbolFilm\Class\Contenido;

class Partido extends Contenido {

    private string $estadio;
    private string $resultado;

    public function getEstadio(): string
    {
        return $this->estadio;
    }

    public function setEstadio(string $estadio): self
    {
        $this->estadio = $estadio;
        return $this;
    }

    public function getResultado(): string
    {
        return $this->resultado;
    }

    public function setResultado(string $resultado): self
    {
        $this->resultado = $resultado;
        return $this;
    }


    public function resumen():string {
        return "Partido: $this->titulo ($this->anio) en $this->estadio.
        Resultado: $this->resultado";
    }



}