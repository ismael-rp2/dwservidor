<?php

namespace Ismael\FutbolFilm\Class;

class Contenido {
    protected string $titulo;
    protected int $anio;

    public function getTitulo(): string
    {
        return $this->titulo;
    }

    public function setTitulo(string $titulo): self
    {
        $this->titulo = $titulo;
        return $this;
    }

    public function getAnio(): int
    {
        return $this->anio;
    }

    public function setAnio(int $anio): self
    {
        $this->anio = $anio;
        return $this;
    }






}