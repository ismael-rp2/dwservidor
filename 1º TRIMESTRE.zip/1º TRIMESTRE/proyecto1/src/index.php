<?php

include_once "./vendor/autoload.php";

use Phroute\Phroute\Exception\HttpRouteNotFoundException;
use Phroute\Phroute\Exception\HttpMethodNotAllowedException; // Agregado para controlar el error 405
use Phroute\Phroute\RouteCollector;
use Ismael\Proyecto1\Controllers\UserController;
use Ismael\Proyecto1\Controllers\PeliculaController;

//Herramienta para cargar las variables de entornor
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();


//Solo inicializamos el RouteCollector una vez para no borrar rutas previas
$router = new RouteCollector();

$router->get('/obtener-passwd', function(){
    include_once  "ejemplos/funciones.php";
    echo create_pass();
});

// RUTAS DE PELÍCULAS
$router->get('/movie/add', function(){
    include_once "app/Views/backend/admin.movie.new.php";
});

$router->post('/movie', function(){
    var_dump($_POST);
    manageFiles($_FILES);
});

// RUTAS DE USUARIO
$router->get('/register', [UserController::class, 'create']);
$router->get('/user/{id}/edit', [UserController::class, 'edit']);
$router->get('/user', [UserController::class, 'index']);
$router->get('/user/{id}', [UserController::class, 'show']);
$router->post('/user', [UserController::class, 'store']);
$router->put('/user/{id}', [UserController::class, 'update']);

// SOLUCIÓN 2: Añadido el parámetro {id} a la ruta DELETE para que coincida con /user/3
$router->delete('/user/{id}', [UserController::class, 'destroy']);

$router->get('/admin', function(){
    return include_once "./app/Views/backend/admin.index.php";
});

$router->get('/', function(){
    return include_once "app/Views/fronted/code.php";
});

$dispatcher = new Phroute\Phroute\Dispatcher($router->getData());

//Controlamos tanto la ruta no encontrada como el metodo no permitido de forma elegante
try {
    $response = $dispatcher->dispatch($_SERVER['REQUEST_METHOD'], parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
} catch(HttpRouteNotFoundException $e) {
    http_response_code(404);
    $response = "Eres muyyyy tonto, zoquete!!!. (Ruta no encontrada)";
} catch(HttpMethodNotAllowedException $e) {
    http_response_code(405);
    $response = "Método HTTP no permitido para esta dirección.";
}

// Imprime la respuesta
echo $response;
