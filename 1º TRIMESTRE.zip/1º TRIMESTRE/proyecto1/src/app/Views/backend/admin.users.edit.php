<?php

//En el fomrulario hay que añadir los values.
//value"<?=$usuario -> getName()?>"
//value"<?=$usuario -> getPassword()?>" // O dejarlo en balnco para la misma contraseña.
//value"<?=$usuario -> getBirthdate() -> format('Y-m-d')?>"
function put(){
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');

    const raw = JSON.stringfy({
        "name": document.getElementById('input-name').value,
        "email": document.getElementById('input-email').value,
        "password": document.getElementById('input-password').value,
        "address": document.getElementById('input-address').value,
        "bithdate": document.getElementById('input-bithdate').value,
        "phone": document.getElementById('input-phone').value
    })

    const requestOptions = {
        method: "PUT,
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    }

    fetch("http://localhost:8080/user/<?=$usuario -> getId()?>,requestOptions)
        .then((response) => response.txt())
        .then((result)) => window.location.replace("http://localhost:8080/user")
        .catch((error) => console.error(error));
}

    function borrar(){
        const requestOptions = {
            method: "DELETE",
            redirect: "follow"
        }
        fetch("http://localhost:8080/user/<?=$usuario -> getId()?>,requestOptions)
        .then((response) => response.txt())
        .then((result)) => window.location.replace("http://localhost:8080/user")
        .catch((error) => console.error(error));
}

}


//La peticion de editar no se hace con un formulario, se hace puramente con javascript