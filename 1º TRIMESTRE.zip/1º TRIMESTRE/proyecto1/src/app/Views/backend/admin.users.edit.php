<?php
// Ensamblador de la vista: Editar Usuario
include_once "templates/header.php";
include_once "templates/sidebar.php";
include_once "templates/main.title.php";

// Cargamos el formulario de edición con el JS.
// La variable $usuario viene inyectada desde el UserController->edit()
include_once "templates/users.edit.content.php";

include_once "templates/footer.php";
?>