<?php
// Ensamblador de la vista: Crear Usuario (PANTALLA COMPLETA, SIN MENÚS)
include_once "templates/header.php";
?>

<!-- Contenedor que ocupa toda la pantalla para centrar el formulario -->
<main class="w-full min-h-screen flex items-center justify-center p-6 bg-[#0A0E17]">

    <?php
    // Cargamos únicamente el formulario
    include_once "templates/user.create.content.php";
    ?>

</main>

<!-- Cerramos el HTML directamente sin usar el footer.php para no arrastrar contenedores del CMS -->
</body>
</html>