<?php
// Ensamblador puro de la vista
include_once "templates/header.php";
include_once "templates/sidebar.php";
include_once "templates/main.title.php";
include_once "templates/main.content.php";
include_once "templates/footer.php";