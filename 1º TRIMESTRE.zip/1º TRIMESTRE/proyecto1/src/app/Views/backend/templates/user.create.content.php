<div class="flex items-center justify-center min-h-[80vh]">
    <div class="bg-[#131822] border border-[#1F2633] rounded-xl p-8 w-full max-w-lg shadow-2xl">
        <div class="mb-8 text-center">
            <h2 class="font-heading text-3xl font-bold text-white uppercase tracking-wider mb-2">
                <?= htmlspecialchars($titulo ?? 'Nuevo Registro') ?>
            </h2>
            <p class="text-sm text-gray-400">
                <?= htmlspecialchars($descripcion ?? '') ?>
            </p>
        </div>

        <!-- El formulario apunta a /user por POST -->
        <form action="/user" method="POST" class="space-y-5">

            <div>
                <label for="name" class="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Nombre Completo</label>
                <input type="text" id="name" name="name" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-3 rounded border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red placeholder-gray-700" placeholder="Ej: Ismael">
            </div>

            <div>
                <label for="email" class="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Correo Electrónico</label>
                <input type="email" id="email" name="email" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-3 rounded border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red placeholder-gray-700" placeholder="usuario@eldensetv.es">
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label for="password" class="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Clave de Acceso</label>
                    <input type="password" id="password" name="password" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-3 rounded border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
                </div>
                <div>
                    <label for="birthdate" class="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">F. Nacimiento</label>
                    <input type="date" id="birthdate" name="birthdate" required class="w-full bg-[#0A0E17] text-gray-400 px-4 py-3 rounded border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
                </div>
            </div>

            <div>
                <label for="address" class="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Dirección Postal</label>
                <input type="text" id="address" name="address" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-3 rounded border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red placeholder-gray-700">
            </div>

            <div>
                <label for="phone" class="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Teléfono</label>
                <input type="tel" id="phone" name="phone" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-3 rounded border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red placeholder-gray-700">
            </div>

            <div class="pt-4">
                <button type="submit" class="w-full bg-brand-red hover:bg-brand-redHover text-white px-5 py-3.5 rounded font-heading text-sm font-semibold tracking-widest uppercase transition-all flex items-center justify-center gap-2">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
                    Registrar en Eldense TV
                </button>
            </div>
        </form>
    </div>
</div>