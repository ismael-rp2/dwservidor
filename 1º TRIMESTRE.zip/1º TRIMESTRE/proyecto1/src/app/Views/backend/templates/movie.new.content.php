<div>
    <h2 class="font-heading text-2xl font-bold text-white uppercase tracking-wider mb-6">Añadir Nuevo Contenido</h2>

    <!-- Fíjate en el enctype, obligatorio para subir la imagen -->
    <form action="/admin/nueva-pelicula" method="POST" enctype="multipart/form-data" class="bg-[#131822] border border-[#1F2633] rounded-xl p-6 space-y-5 max-w-2xl shadow-lg">

        <!-- Título -->
        <div>
            <label for="titulo" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Título de la película / partido</label>
            <input type="text" name="titulo_contenido" id="titulo" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red placeholder-gray-600" placeholder="Ej: El Milagro de Elda">
        </div>

        <!-- Descripción -->
        <div>
            <label for="descripcion" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Descripción</label>
            <textarea name="descripcion_contenido" id="descripcion" rows="4" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red placeholder-gray-600" placeholder="Escribe el resumen del contenido..."></textarea>
        </div>

        <!-- Imagen -->
        <div>
            <label for="imagen" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Carátula (Imagen JPG/PNG)</label>
            <input type="file" name="imagen_adjunta" id="imagen" required class="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-[#1F2633] file:text-white hover:file:bg-gray-700 cursor-pointer border border-[#222A3B] rounded-lg bg-[#0A0E17]">
        </div>

        <!-- Botón Submit -->
        <div class="pt-4">
            <button type="submit" class="bg-brand-red hover:bg-brand-redHover text-white px-5 py-2.5 rounded-lg font-heading text-sm font-semibold tracking-wider flex items-center gap-2 shadow-md shadow-brand-red/25 transition-all">
                <svg class="w-4 h-4 stroke-[2.5]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                GUARDAR CONTENIDO
            </button>
        </div>
    </form>
</div>