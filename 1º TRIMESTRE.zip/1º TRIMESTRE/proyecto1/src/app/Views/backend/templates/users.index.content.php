<div>
    <div class="flex items-center justify-between mb-6">
        <h2 class="font-heading text-2xl font-bold text-white uppercase tracking-wider">Gestión de Usuarios CMS</h2>
        <button class="bg-brand-red hover:bg-brand-redHover text-white px-4 py-2 rounded-lg font-heading text-sm font-semibold tracking-wider transition-all shadow-md">
            + NUEVO USUARIO
        </button>
    </div>

    <!-- Añadimos overflow-x-auto por si la tabla es muy ancha -->
    <div class="bg-[#131822] border border-[#1F2633] rounded-xl shadow-lg overflow-x-auto">
        <table class="w-full text-left text-sm text-gray-400 whitespace-nowrap">
            <!-- NUEVAS COLUMNAS (THEAD) -->
            <thead class="bg-[#0A0E17] text-xs uppercase font-bold text-gray-500 border-b border-[#1F2633]">
            <tr>
                <th scope="col" class="px-6 py-4">Usuario</th>
                <th scope="col" class="px-6 py-4">Dirección</th>
                <th scope="col" class="px-6 py-4">Teléfono</th>
                <th scope="col" class="px-6 py-4">F. Nacimiento</th>
                <th scope="col" class="px-6 py-4">Email</th>
                <th scope="col" class="px-6 py-4">Contraseña</th>
                <th scope="col" class="px-6 py-4 text-right">Acciones</th>
            </tr>
            </thead>

            <!-- DATOS DINÁMICOS (TBODY) -->
            <tbody class="divide-y divide-[#1F2633]">
            <?php if (!empty($usuarios)): ?>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr class="hover:bg-[#1A212D] transition-colors">
                        <td class="px-6 py-4 font-medium text-gray-200">
                            <?php echo htmlspecialchars($usuario->getName()); ?>
                        </td>
                        <td class="px-6 py-4">
                            <?php echo htmlspecialchars($usuario->getAddress()); ?>
                        </td>
                        <td class="px-6 py-4">
                            <?php echo htmlspecialchars($usuario->getPhone()); ?>
                        </td>
                        <td class="px-6 py-4">
                            <!-- getBirthdate() devuelve un objeto DateTime, usamos format() para mostrarlo bonito -->
                            <?php echo htmlspecialchars($usuario->getBirthdate()->format('d/m/Y')); ?>
                        </td>
                        <td class="px-6 py-4 text-brand-cyan">
                            <?php echo htmlspecialchars($usuario->getEmail()); ?>
                        </td>
                        <td class="px-6 py-4 tracking-widest text-gray-500 font-bold">
                            <!-- Por seguridad, NUNCA enviamos el hash real a la vista. Imprimimos asteriscos directamente -->
                            ********
                        </td>
                        <td class="px-6 py-4 text-right space-x-3">
                            <a href="/user/<?php echo urlencode($usuario->getId()); ?>/edit" class="text-blue-400 hover:text-blue-300 transition-colors">Editar</a>
                            <a href="#" class="text-brand-red hover:text-red-400 transition-colors font-semibold">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="px-6 py-4 text-center text-gray-500">No hay usuarios registrados en la base de datos.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>