<div>
    <div class="flex items-center justify-between mb-6">
        <h2 class="font-heading text-2xl font-bold text-white uppercase tracking-wider">Editar Usuario</h2>
        <!-- Botón de borrar llamando a la función JS -->
        <button onclick="borrar()" type="button" class="bg-brand-red hover:bg-brand-redHover text-white px-4 py-2 rounded-lg font-heading text-sm font-semibold tracking-wider transition-all shadow-md">
            ELIMINAR USUARIO
        </button>
    </div>

    <!-- Formulario gestionado por JS (event.preventDefault() evita que el navegador recargue la página) -->
    <form onsubmit="event.preventDefault(); put();" class="bg-[#131822] border border-[#1F2633] rounded-xl p-6 space-y-5 max-w-2xl shadow-lg">

        <div>
            <label for="input-name" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nombre</label>
            <input type="text" id="input-name" value="<?= htmlspecialchars($usuario->getName()) ?>" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
        </div>

        <div>
            <label for="input-email" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Correo Electrónico</label>
            <input type="email" id="input-email" value="<?= htmlspecialchars($usuario->getEmail()) ?>" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
        </div>

        <div>
            <label for="input-password" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Contraseña (Dejar en blanco para mantener la actual)</label>
            <!-- El value está vacío para no exponer el hash de la BD -->
            <input type="password" id="input-password" value="" class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
        </div>

        <div>
            <label for="input-address" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Dirección</label>
            <input type="text" id="input-address" value="<?= htmlspecialchars($usuario->getAddress()) ?>" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
        </div>

        <div>
            <label for="input-phone" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Teléfono</label>
            <input type="text" id="input-phone" value="<?= htmlspecialchars($usuario->getPhone()) ?>" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
        </div>

        <div>
            <label for="input-birthdate" class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Fecha de Nacimiento</label>
            <!-- Formateamos la fecha para que el input type="date" la lea correctamente -->
            <input type="date" id="input-birthdate" value="<?= htmlspecialchars($usuario->getBirthdate()->format('Y-m-d')) ?>" required class="w-full bg-[#0A0E17] text-gray-200 px-4 py-2 rounded-lg border border-[#222A3B] focus:outline-none focus:border-brand-red focus:ring-1 focus:ring-brand-red">
        </div>

        <div class="pt-4 flex gap-3">
            <button type="submit" class="bg-brand-red hover:bg-brand-redHover text-white px-5 py-2.5 rounded-lg font-heading text-sm font-semibold tracking-wider shadow-md transition-all">
                GUARDAR CAMBIOS
            </button>
            <a href="/user" class="bg-[#1F2633] hover:bg-gray-700 text-white px-5 py-2.5 rounded-lg font-heading text-sm font-semibold tracking-wider transition-all">
                CANCELAR
            </a>
        </div>
    </form>
</div>

<script>
    // JS corregido de errores de sintaxis (JSON.stringify, method: "PUT", .text())
    function put(){
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');

        const raw = JSON.stringify({
            "name": document.getElementById('input-name').value,
            "email": document.getElementById('input-email').value,
            "password": document.getElementById('input-password').value,
            "address": document.getElementById('input-address').value,
            "birthdate": document.getElementById('input-birthdate').value,
            "phone": document.getElementById('input-phone').value
        });

        const requestOptions = {
            method: "PUT",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };

        // Cambiamos URL a relativa y urlencode para mayor seguridad
        fetch("/user/<?= urlencode($usuario->getId()) ?>", requestOptions)
            .then((response) => response.text())
            .then((result) => window.location.replace("/user"))
            .catch((error) => console.error(error));
    }

    function borrar(){
        // Añadimos confirmación de seguridad
        if(confirm("¿Estás seguro de que quieres eliminar este usuario de Eldense TV?")) {
            const requestOptions = {
                method: "DELETE",
                redirect: "follow"
            };
            fetch("/user/<?= urlencode($usuario->getId()) ?>", requestOptions)
                .then((response) => response.text())
                .then((result) => window.location.replace("/user"))
                .catch((error) => console.error(error));
        }
    }
</script>