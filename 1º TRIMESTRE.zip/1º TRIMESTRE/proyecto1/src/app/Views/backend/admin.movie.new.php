<?php
// Ensamblador puro de la vista: Nuevo Contenido
include_once "templates/header.php";
include_once "templates/sidebar.php";
include_once "templates/main.title.php";

// Cargamos el formulario (archivo que vamos a crear ahora)
include_once "templates/movie.new.content.php";

include_once "templates/footer.php";
?>