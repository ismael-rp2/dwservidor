<?php
// Ensamblador de la vista: Listado de Usuarios
include_once "templates/header.php";
include_once "templates/sidebar.php";
include_once "templates/main.title.php";

// Cargamos la tabla de usuarios
include_once "templates/users.index.content.php";

include_once "templates/footer.php";
?>