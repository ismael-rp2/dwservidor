<?php

namespace Ismael\Proyecto1\Interfaces;
interface ControllerInterface
{
    //Ver todos los usuarios
    public function index();

    //Ver un solo usuario
    public function show(int $id);

    public function create();

    //Borrar un usuario
}