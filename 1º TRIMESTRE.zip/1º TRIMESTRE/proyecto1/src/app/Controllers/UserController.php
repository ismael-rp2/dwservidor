<?php

namespace Ismael\Proyecto1\Controllers;

use Ismael\Proyecto1\Class\User;
use Ismael\Proyecto1\Interfaces\ControllerInterface;
use Ismael\Proyecto1\Models\UserModel;
use Respect\Validation\Exceptions\NestedValidationException;
use Respect\Validation\Validator as v;

class UserController implements ControllerInterface
{

    public function index() {
        // 1. Obtenemos los usuarios de la base de datos a través del modelo
        $usuarios = UserModel::getUsers();

        // 2. Cargamos la vista pasándole los datos
        return include_once __DIR__ . "/../Views/backend/admin.users.index.php";
    }

    public function show(int $id)
    {
        return "Me estas pidiendo los datos del usuario: $id";
    }

    public function create()
    {
        $titulo = "Creación de un nuevo usuario";
        $descripcion = "Inserta todos los datosdel formulario para crear un usuario";
        include_once "app/Views/backend/admin.user.create.php";
        //Esto tiene que ir en el html de la vista
        //<form action="/user" method="post">
        //<label for="input-name"></label>
        //<input id="input-name" name="name" type="text" placeholder="Texto">

    }

    public function update(int $id)
    {
        $datosAModficar = json_decode(file_get_contents("php://input"), true);

        $datosAModficar['id'] = $id;

        $validacion = User::validateUserUpdate($datosAModficar);

        //Leer un usuario dela base de datos
        $usuarioAntiguo = UserModel::getUserById($id);

        if($usuarioAntiguo === false){
            return "ERROR - No se ha encontrado el usuario a modificar";
        } else {
            $usuarioNuevo = User::updateFromArray($usuarioAntiguo, $datosAModficar);

            if(UserModel::updateUser($usuarioNuevo)){
                return "Usuario modificado correctamente";
            } else {
                return "ERROR - No se ha podido modificar el usuario";
            }
        }
    }


    public function delete(int $id)
    {
        // TODO: Implement delete() method.
    }

    public function store()
    {
        //Validar los datos que me han llegado

        $validacion = User::validateUserCreation($_POST);

        if($validacion === true){
            $usuario = User::createFromArray($_POST);

            //Enviar al modelo la instancia del objeto que debeguardar en la Base de datos
            if(!UserModel::saveUser($usuario)){
                return "Ha ocurrido un error en el almacenamiento";
            } else {
                header("Location: /user");
            }
        } else {
            //Ha habido errores de validacion
            foreach ($validacion as $error){
                echo $error."<br>";
            }
        }



    }

    public function edit(int $id)
    {
        //Necesito recuperar el usuaio de la base de datos
        $usuario = UserModel::getUserById($id);

        //Voy a incluir la vista de edición de datos
        include_once "app/Views/backend/admin.user.edit.php";

    }

    public function destroy(int $id)
    {

        if(UserModel::deleteUser($id)){
            //Si se ha borrado correctamente
            http_response_code(200);
            header('Content-Type: application/json');
            return json_encode([
                "error" => false,
                "message" => "El usuario se ha eliminado correctamente",
                "code" => 200
            ]);

        } else {
            //Si NO se ha borrado correctamente
            http_response_code(404);
            header('Content-Type: application/json');
            return json_encode([
                "error" => true,
                "message" => "NO se ha podido eliminar el usuario",
                "code" => 404
            ]);
        }
    }


    public function login(){
        //Muestra el formulario para poder hacer login

    }

    public function signin(){
        //Recoge los datos que me ha enviado el formulario
        var_dump($_POST);

        //Válida el ususuario
        $usuario = UserModel::getUserByEmail($_POST['email']);

        if ($usuario){
            //Guarda en la sesión los datos necesario para alamcenar el usuario
            if(password_verify($_POST['password'], $usuario -> getPassword())){
                //La contraseña a sido verificada
                session_start();
                $_SESSION['user'] = $usuario;

            } else {
                return "La contraseña es incorrecta";
            }

        } else {
            return "No se ha podido encontrar el usuario";
        }
    }


    public function logout(){
        session_destroy();
    }

}