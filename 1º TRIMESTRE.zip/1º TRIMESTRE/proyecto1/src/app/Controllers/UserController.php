<?php

namespace Ismael\Proyecto1\Controllers;

use Ismael\Proyecto1\Class\User;
use Ismael\Proyecto1\Interfaces\ControllerInterface;
use Ismael\Proyecto1\Models\UserModel;
use Respect\Validation\Exceptions\NestedValidationException;
use Respect\Validation\Validator as v;

class UserController implements ControllerInterface
{

    public function index()
    {
        return "Página para ver todos los usuarios";
    }

    public function show(int $id)
    {
        return "Me estas pidiendo los datos del usuario: $id";
    }

    public function create()
    {
        // TODO: Implement create() method.
    }

    public function update(int $id)
    {
        $datosAModficar = json_decode(file_get_contents("php://input"), true);

        $datosAModficar['id'] = $id;

        $validacion = User::validateUserUpdate($datosAModficar);

        //Leer un usuario dela base de datos
        $usuarioAntiguo = UserModel::getUserById($id);

        if($usuarioAntiguo === false){
            return "ERROR - No se ha encontrado el usuario a modificar";
        } else {
            $usuarioNuevo = User::updateFromArray($usuarioAntiguo, $datosAModficar);

            if(UserModel::updateUser($usuarioNuevo)){
                return "Usuario modificado correctamente";
            } else {
                return "ERROR - No se ha podido modificar el usuario";
            }
        }
    }


    public function delete(int $id)
    {
        // TODO: Implement delete() method.
    }

    public function store()
    {
        //Validar los datos que me han llegado

        $validacion = User::validateUserCreation($_POST);

        if($validacion === true){
            $usuario = User::createFromArray($_POST);

            //Enviar al modelo la instancia del objeto que debeguardar en la Base de datos
            if(!UserModel::saveUser($usuario)){
                return "Ha ocurrido un error en el almacenamiento";
            } else {
                return "Se ha guardado correctamente";
            }
        } else {
            //Ha habido errores de validacion
            foreach ($validacion as $error){
                echo $error."<br>";
            }
        }



    }

    public function edit(int $id)
    {
        // TODO: Implement edit() method.
    }

    public function destroy(int $id)
    {

        if(UserModel::deleteUser($id)){
            //Si se ha borrado correctamente
            http_response_code(200);
            header('Content-Type: application/json');
            return json_encode([
                "error" => false,
                "message" => "El usuario se ha eliminado correctamente",
                "code" => 200
            ]);

        } else {
            //Si NO se ha borrado correctamente
            http_response_code(404);
            header('Content-Type: application/json');
            return json_encode([
                "error" => true,
                "message" => "NO se ha podido eliminar el usuario",
                "code" => 404
            ]);
        }

    }
}