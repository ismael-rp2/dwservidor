<?php

namespace Ismael\proyecto1\Controllers;

use Ismael\proyecto1\Interfaces\ControllerInterface;
use Ismael\proyecto1\Models\UserModel;

class PeliculaController implements ControllerInterface
{

    public function index()
    {
        /*
         * Necesito preguntar al model y que me de unb array con
         * los objetos que representen todos los usuarios que hay en la BD
        */

        $usuarios = UserModel::getUsers();

        //Tengo que crear una vista donde se muestre una tabla con todos los usuarios
        include_once "";
    }

    public function show(int $id)
    {
        // TODO: Implement show() method.
    }

    public function create()
    {
        // TODO: Implement create() method.
    }

    public function update(int $id)
    {
       // TODO: Implemet update() methos.
    }

    public function delete(int $id)
    {
        // TODO: Implement delete() method.
    }

    public function store()
    {
        // TODO: Implement store() method.
    }

    public function edit(int $id)
    {
        // TODO: Implement edit() method.
    }

    public function destroy(int $id)
    {
        // TODO: Implement destroy() method.
    }
}