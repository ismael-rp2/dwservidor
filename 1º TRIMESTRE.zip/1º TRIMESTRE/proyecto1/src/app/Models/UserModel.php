<?php

namespace Ismael\proyecto1\Models;

use PDO;

class UserModel
{

    public static function getUsers():array{
        try {
            $conexion = new PDO("mysql:host=mariadb;dbname=netflix",
                "ismael",
                "ismael"); //Recibe 3 parametros

            $conexion->setAttribute(PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION);

        } catch(\PDOException $e){
            echo $e -> getMessage();
        }

        $sql = "SELECT * FROM users";
        $stmt = $conexion -> prepare($sql);

        $stmt -> execute();

        $resultado = $stmt -> fetchAll();

        var_dump($resultado);

        return [];
    }



}
