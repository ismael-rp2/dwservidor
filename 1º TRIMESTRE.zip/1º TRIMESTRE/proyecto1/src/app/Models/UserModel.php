<?php

namespace Ismael\Proyecto1\Models;

use Ismael\Proyecto1\Class\User;
use PDO;
use PDOException;

class UserModel
{

    public static function getUsers():array{
        try {
            $conexion = new PDO("mysql:host=mariadb;dbname=netflix",
                "ismael",
                "ismael"); //Recibe 3 parametros

            $conexion->setAttribute(PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION);

        } catch(\PDOException $e){
            echo $e -> getMessage();
        }

        $sql = "SELECT * FROM users";
        $stmt = $conexion -> prepare($sql);

        $stmt -> execute();

        $resultado = $stmt -> fetchAll(PDO::FETCH_ASSOC);

        var_dump($resultado);

        return \Ismael\Proyecto1\Class\User::createMultiplateUsersFromArray($resultado);

        /*
        echo "El nombre del usuario es: ".$resultado[0]['name'];
        echo "El nombre del usuario es: ".$resultado[0][3];
        */

    }


    public static function saveUser(User $user):bool{
        $conexion = "";
        try{
            $conexion = new PDO("mysql:host=mariadb;dbname=netflix","root", "toor");

            $conexion -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e){
            echo $e -> getMessage();
        }

        $sql = "INSERT INTO users(name, address, phone, birthdate, password, email)
        values (:nombre, :direccion, :telefono, STR_TO_DATE(:fecha, '%Y-%m-%d'), :contrasenya, :email)";
        $stmt = $conexion -> prepare($sql);

        $stmt -> bindValue("nombre", $user -> getName());
        $stmt -> bindValue("direccion", $user -> getAddress());
        $stmt -> bindValue("telefono", $user -> getPhone());
        $stmt -> bindValue("fecha", $user -> getBirthdate() -> format("Y-m-d"));
        $stmt -> bindValue("contrasenya", $user -> getPassword());
        $stmt -> bindValue("email", $user -> getEmail());

        $stmt -> execute();

        $reultado = $stmt -> rowCount();

        var_dump($reultado);

        if(!$reultado){
            return false;
        } else {
            return true;
        }

    }

    public static function deleteUser(int $idUser):bool{
        $conexion = "";

        try {
            $dsn = "mysql:host=mariadb;dbname=" . $_ENV['MARIADB_DBNAME'];
            $usuarioBD = $_ENV['MARIADB_USER'];
            $passwordBD = $_ENV['MARIADB_PASSWORD'];
            $conexion = new PDO($dsn, $usuarioBD, $passwordBD);

            $conexion -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        } catch (PDOException $e){
            echo $e -> getMessage().'<br>';
        }

        $sql = "DELETE FROM users WHERE id = ?";

        $stmt = $conexion -> prepare($sql);

        $stmt -> bindValue(1, $idUser);

        $stmt -> execute();

        if($stmt -> rowCount()){
            return true;
        } else {
            return false;
        }

    }


    public static function getUserById(int $idUser):User|false{
        $conexion = "";
        try{

            $conexion = new PDO("mysql:host=mariadb;dbname=netflix", "root", "toor");
            $conexion -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        } catch (PDOException $e){
            echo $e -> getMessage();
        }

        $sql = "SELECT * FROM users WHERE id=:id";

        $stmt = $conexion -> prepare($sql);

        $stmt -> bindValue("id", $idUser);

        $stmt-> execute();

        $resultado = $stmt -> fetch(PDO::FETCH_ASSOC);

        if($resultado){
            return User::createFromArray($resultado);
        } else {
            return false;
        }

    }



    public static function updateUser(User $user):bool{
        $conexion = "";
        try{
            $conexion = new PDO("mysql:host=mariadb;dbname=netflix","root", "toor");

            $conexion -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e){
            echo $e -> getMessage();
        }

        $sql = "UPDATE users SET address =:direccion,
                 birthdate =STR_TO_DATE(:fecha, '%Y-%m-%d'),
                 email =:correo,
                 password =:contrasenya,
                 phone =:telefono,
                 name =:nombre WHERE id=:id";
                 

        $stmt = $conexion -> prepare($sql);

        $stmt -> bindValue("nombre", $user -> getName());
        $stmt -> bindValue("direccion", $user -> getAddress());
        $stmt -> bindValue("telefono", $user -> getPhone());
        $stmt -> bindValue("fecha", $user -> getBirthdate() -> format("Y-m-d"));
        $stmt -> bindValue("contrasenya", $user -> getPassword());
        $stmt -> bindValue("correo", $user -> getEmail());
        $stmt-> bindValue("id", $user->getId());

        $stmt -> execute();

        $reultado = $stmt -> rowCount();

        var_dump($reultado);

        if(!$reultado){
            return false;
        } else {
            return true;
        }

    }

    

}
