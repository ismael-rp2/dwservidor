<?php

namespace Ismael\Proyecto1\Models;

use http\Client\Curl\User;
use PDO;

class UserModel
{

    public static function getUsers():array{
        try {
            $conexion = new PDO("mysql:host=mariadb;dbname=netflix",
                "ismael",
                "ismael"); //Recibe 3 parametros

            $conexion->setAttribute(PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION);

        } catch(\PDOException $e){
            echo $e -> getMessage();
        }

        $sql = "SELECT * FROM users";
        $stmt = $conexion -> prepare($sql);

        $stmt -> execute();

        $resultado = $stmt -> fetchAll(PDO::FETCH_ASSOC);

        var_dump($resultado);

        return \Ismael\Proyecto1\Class\User::createMultiplateUsersFromArray($resultado);


        /*
        echo "El nombre del usuario es: ".$resultado[0]['name'];
        echo "El nombre del usuario es: ".$resultado[0][3];
        */

        return [];
    }



}
