<?php

namespace Ismael\Airsoft\Models;

use Ismael\Airsoft\Class\Operador;
use PDO;
use PDOException;

class OperadorModel {

    /**
     * Métodu privado para establecer la conexión PDO a MariaDB
     * utilizando los datos del archivo .env
     */
    private static function conectar() {
        try {
            $host = $_ENV['MARIADB_HOST'];
            $dbname = $_ENV['MARIADB_DBNAME'];
            $user = $_ENV['MARIADB_USER'];
            $password = $_ENV['MARIADB_PASSWORD'];

            // Creamos la instancia de PDO
            $conexion = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);

            // Configuramos PDO para que lance excepciones si hay errores SQL
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $conexion;

        } catch (PDOException $e) {
            // Si falla la conexión, detenemos la ejecución y mostramos el error
            echo("Error de conexión a la base de datos: " . $e->getMessage());
        }
    }

    /**
     * Métodq estático para guardar un operador en la base de datos
     * Recibe un objeto de tipo Operador
     */
    public static function saveOperador(Operador $operador): bool {
        // 1. Llamamos a nuestra función de conexión
        $db = self::conectar();

        // 2. Preparamos la sentencia SQL con marcadores (:parametro)
        // ¡Nunca pongas $_POST directamente aquí para evitar Inyecciones SQL!
        $sql = "INSERT INTO operadores (apodo, email, password, rol, especialidad) 
                VALUES (:apodo, :email, :password, :rol, :especialidad)";

        $stmt = $db->prepare($sql);

        // 3. Ejecutamos pasando los datos obtenidos del objeto Operador
        return $stmt->execute([
            ':apodo' => $operador->getApodo(),
            ':email' => $operador->getEmail(),
            ':password' => $operador->getPassword(),
            ':rol' => $operador->getRol(),
            ':especialidad' => $operador->getEspecialidad()
        ]);
    }

    //Devolver los datos del usuario si el email coincide con el que se a recibido
    public static function getOperadorByEmail(string $email): Operador|false {
        // 1. Conectamos a la base de datos
        $db = self::conectar();

        // 2. Preparamos la consulta SQL buscando por el email
        $sql = "SELECT * FROM operadores WHERE email = :email LIMIT 1";
        $stmt = $db->prepare($sql);

        // 3. Ejecutamos pasando el parámetro de forma segura
        $stmt->execute([':email' => $email]);

        // 4. Recuperamos el resultado como un array asociativo
        $datos = $stmt->fetch(PDO::FETCH_ASSOC);

        // 5. Si no se encuentra el usuario, devolvemos false
        if (!$datos) {
            return false;
        }

        // 6. Si se encuentra, creamos un objeto Operador y rellenamos sus datos
        $operador = new Operador();
        $operador->setId($datos['id']);
        $operador->setApodo($datos['apodo']);
        $operador->setEmail($datos['email']);
        $operador->setPassword($datos['password']);
        $operador->setRol($datos['rol']);
        $operador->setEspecialidad($datos['especialidad']);

        return $operador;
    }


    public static function getAllOperadores():array{
        //Nos conecatamos a la base de datos
        $conexion =
        $db = self::conectar();

        //Preparamos la consulta sql
        $sql = "SELECT * FROM operadores";
        $stmt = $db -> prepare($sql);

    //$stmt->fetchAll(PDO::FETCH_ASSOC) para obtener todas las filas de golpe
    //y luego recorrerlas con un bucle foreach para transformarlas en objetos Operador).

    }



}