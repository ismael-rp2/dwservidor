<?php

namespace Ismael\Airsoft\Controllers;

use Ismael\Airsoft\Class\Operador;
use Ismael\Airsoft\Models\OperadorModel;

class OperadorController {

    public static function index() {
        // 1. Pedimos los operadores al modelo
        $operadores = OperadorModel::getAllOperadores();

        require_once __DIR__ . '/../Views/backend/operadores_view.php';
    }


    public static function store() {
        //Recoger los datosw
        $apodo = $_POST['apodo'] ?? null;
        $email = $_POST['email'] ?? null;
        $password = $_POST['password'] ?? null;

        //Validar que los campos obligatorios tengan texto
        if (empty($_POST['apodo']) || empty($_POST['email']) || empty($_POST['password'])) {
            return "Error: Faltan campos obligatorios";
        }

        //Encriptar la contraseña
        $passwordEncriptada = password_hash($_POST['password'], PASSWORD_DEFAULT);

        //Instanciar un nuvo objeto
        $operador = new Operador();
        $operador -> setApodo($_POST['apodo']);
        $operador -> setEmail($_POST['email']);
        $operador -> setPassword($passwordEncriptada);
        $operador -> setRol($_POST['rol'] ?? 'jugaor'); //Si no ha puesto un rol, es jugador
        $operador -> setEspecialidad($_POST['especialidad']);
        $resultado = OperadorModel::saveOperador($operador);

        //Redirigir o deolver la respuesta
        try {
            $resultado = OperadorModel::saveOperador($operador);
            if($resultado) {
                return "Operador registrado con éxito";
            }
        } catch (\Exception $e) {
            return "Error en la base de datos: " . $e->getMessage();
        }
    }

    // Mostrar formulario de edición con los datos actuales del operador
    public static function edit($id) {
        $operador = OperadorModel::getOperadorById($id);

        if (!$operador) {
            header('Location: /operadores');
            exit;
        }

        require_once __DIR__ . '/../Views/backend/operador_edit_view.php';
    }

    // Procesar la actualización en la base de datos
    public static function update($id) {
        $apodo = $_POST['apodo'] ?? null;
        $email = $_POST['email'] ?? null;
        $rol = $_POST['rol'] ?? 'jugador';
        $especialidad = $_POST['especialidad'] ?? 'Asalto';

        if (empty($apodo) || empty($email)) {
            return "Error: Faltan campos obligatorios.";
        }

        $operador = new \Ismael\Airsoft\Class\Operador();
        $operador->setId($id);
        $operador->setApodo($apodo);
        $operador->setEmail($email);
        $operador->setRol($rol);
        $operador->setEspecialidad($especialidad);

        $resultado = OperadorModel::updateOperador($operador);

        if ($resultado) {
            header('Location: /operadores');
            exit;
        } else {
            return "Error al actualizar el operador.";
        }
    }



    public static function delete($id) {
        OperadorModel::deleteOperador($id);
        header('Location: /operadores');
        exit;
    }
}

