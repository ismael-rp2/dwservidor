<?php

namespace Ismael\Airsoft\Controllers;

use Ismael\Airsoft\Models\OperadorModel;

class OperadorController {

    public static function index() {
        // 1. Pedimos los operadores al modelo
        $operadores = OperadorModel::getAllOperadores();

        // 2. Comprobación rápida para el examen:
        // Como de momento la base de datos está vacía, esto devolverá un array vacío [].
        // Vamos a volcarlo formateado en JSON para que el navegador lo muestre como texto plano:

        // Convertimos el array de objetos a un string JSON legible
        return "<pre>" . json_encode($operadores, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
    }
}

