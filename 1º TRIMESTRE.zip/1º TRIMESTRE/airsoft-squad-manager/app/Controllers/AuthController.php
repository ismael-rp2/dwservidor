<?php

namespace Ismael\Airsoft\Controllers;

use Ismael\Airsoft\Class\Operador;
use Ismael\Airsoft\Models\OperadorModel;


class AuthController {

    // Muestra la vista de login (la crearemos enseguida)
    public static function showLogin() {
        require_once __DIR__ . '/../Views/backend/login_view.php';
    }

    // Muestra la vista de registro
    public static function showRegister() {
        require_once __DIR__ . '/../Views/backend/register_view.php';
    }

    // Procesa el formulario de login
    public static function login() {
        session_start();
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        // Buscamos al operador por su email usando el modelo
        // (Nota: Tendremos que asegurarnos de tener un método getOperadorByEmail en el modelo)
        $operador = OperadorModel::getOperadorByEmail($email);

        if ($operador && password_verify($password, $operador->getPassword())) {
            // Credenciales correctas: Guardamos la sesión
            $_SESSION['user_id'] = $operador->getId();
            $_SESSION['user_apodo'] = $operador->getApodo();
            $_SESSION['user_rol'] = $operador->getRol();

            // Redirigimos al panel de operadores
            header('Location: /operadores');
            exit;
        } else {
            return "Error: Credenciales incorrectas";
        }
    }

    // Cerrar sesión
    public static function logout() {
        session_start();
        session_destroy();
        header('Location: /login');
        exit;
    }


    public static function register() {
        // 1. Recoger los datos enviados por POST
        $apodo = $_POST['apodo'] ?? null;
        $email = $_POST['email'] ?? null;
        $password = $_POST['password'] ?? null;
        $rol = $_POST['rol'] ?? 'jugador';
        $especialidad = $_POST['especialidad'] ?? 'Asalto';

        // 2. Validación básica
        if (empty($apodo) || empty($email) || empty($password)) {
            return "Error: Faltan campos obligatorios para el registro.";
        }

        // 3. Encriptar la contraseña
        $passwordEncriptada = password_hash($password, PASSWORD_DEFAULT);

        // 4. Instanciar el objeto Operador (LA ENTIDAD) y rellenarlo
        $operador = new Operador();
        $operador->setApodo($apodo);
        $operador->setEmail($email);
        $operador->setPassword($passwordEncriptada);
        $operador->setRol($rol);
        $operador->setEspecialidad($especialidad);

        // 5. Guardar en la base de datos usando OperadorModel
        try {
            $resultado = OperadorModel::saveOperador($operador);

            if ($resultado) {
                header('Location: /login');
                exit;
            } else {
                return "Error al registrar el operador en la base de datos.";
            }
        } catch (\Exception $e) {
            return "Error crítico o email duplicado: " . $e->getMessage();
        }
    }


}