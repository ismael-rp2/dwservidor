<?php

namespace App\Class;
class Operador
{

    //Propiedades
    private $id;
    private $apodo;
    private $email;
    private $password;
    private $rol;
    private $especialidad;

    //Constructor
    public function __construct(){
        $this -> usedContent = [];
    }


    //Getter y Setter
    public function getUsedContent(): array
    {
        return $this->usedContent;
    }

    public function setUsedContent(array $usedContent): Operador
    {
        $this->usedContent = $usedContent;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     * @return Operador
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getApodo()
    {
        return $this->apodo;
    }

    /**
     * @param mixed $apodo
     * @return Operador
     */
    public function setApodo($apodo)
    {
        $this->apodo = $apodo;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     * @return Operador
     */
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     * @return Operador
     */
    public function setPassword($password)
    {
        $this->password = $password;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getRol()
    {
        return $this->rol;
    }

    /**
     * @param mixed $rol
     * @return Operador
     */
    public function setRol($rol)
    {
        $this->rol = $rol;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getEspecialidad()
    {
        return $this->especialidad;
    }

    /**
     * @param mixed $especialidad
     * @return Operador
     */
    public function setEspecialidad($especialidad)
    {
        $this->especialidad = $especialidad;
        return $this;
    }
}

