<?php

namespace Ismael\Airsoft\Class;
use JsonSerializable;

class Operador implements JsonSerializable {
    // Propiedades alineadas con la base de datos
    private $id;
    private $apodo;
    private $email;
    private $password;
    private $rol;
    private $especialidad;

    // Constructor vacío (o puedes prepararlo opcionalmente)
    public function __construct() {
    }

    // Getters y Setters

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    public function getApodo()
    {
        return $this->apodo;
    }

    public function setApodo($apodo)
    {
        $this->apodo = $apodo;
        return $this;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

    public function getPassword()
    {
        return $this->password;
    }

    public function setPassword($password)
    {
        $this->password = $password;
        return $this;
    }

    public function getRol()
    {
        return $this->rol;
    }

    public function setRol($rol)
    {
        $this->rol = $rol;
        return $this;
    }

    public function getEspecialidad()
    {
        return $this->especialidad;
    }

    public function setEspecialidad($especialidad)
    {
        $this->especialidad = $especialidad;
        return $this;
    }

    // Método obligatorio de la interfaz JsonSerializable
    public function jsonSerialize(): array {
        return [
            'id' => $this->id,
            'apodo' => $this->apodo,
            'email' => $this->email,
            'rol' => $this->rol,
            'especialidad' => $this->especialidad
            // (Opcional: omitimos el password por seguridad)
        ];
    }
}