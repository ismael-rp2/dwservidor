<!DOCTYPE html>
<html class="dark" lang="es">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Airsoft Squad Manager - Editar Operador</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#4edea3",
                        "secondary": "#4cd7f6",
                        "surface": "#0b1326",
                        "surface-container": "#171f33",
                        "surface-container-high": "#222a3d",
                        "surface-container-lowest": "#060e20",
                        "surface-variant": "#2d3449",
                        "text-primary": "#f8fafc",
                        "text-secondary": "#94a3b8",
                        "on-surface": "#dae2fd",
                        "outline": "#86948a",
                        "glass-panel": "rgba(30, 41, 59, 0.7)",
                        "glass-border": "rgba(255, 255, 255, 0.1)"
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-surface text-on-surface min-h-screen flex flex-col justify-between font-['Inter']">

<main class="w-full flex-1 flex flex-col justify-center items-center px-4 py-12">
    <div class="relative w-full max-w-xl">
        <div class="rounded-2xl bg-surface-container-high/60 backdrop-blur-xl border border-glass-border shadow-2xl p-8 flex flex-col space-y-6">

            <div class="flex flex-col space-y-1">
                <span class="text-xs uppercase tracking-widest text-primary font-bold">MODIFICACIÓN DE EXPEDIENTE</span>
                <h1 class="text-2xl text-text-primary font-bold">Editar Operador #OP-0<?php echo $operador->getId(); ?></h1>
            </div>

            <div class="w-full h-px bg-glass-border"></div>

            <!-- FORMULARIO DE EDICIÓN -->
            <form action="/operadores/editar/<?php echo $operador->getId(); ?>" method="POST" class="flex flex-col space-y-4">

                <!-- Apodo -->
                <div class="flex flex-col space-y-1">
                    <label class="text-xs text-on-surface font-semibold">APODO / INDICATIVO</label>
                    <input type="text" name="apodo" value="<?php echo htmlspecialchars($operador->getApodo()); ?>" required class="w-full h-11 px-3.5 rounded-lg bg-surface-container-lowest border border-glass-border text-text-primary text-sm focus:outline-none focus:ring-1 focus:ring-primary"/>
                </div>

                <!-- Email -->
                <div class="flex flex-col space-y-1">
                    <label class="text-xs text-on-surface font-semibold">EMAIL SEGURO</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($operador->getEmail()); ?>" required class="w-full h-11 px-3.5 rounded-lg bg-surface-container-lowest border border-glass-border text-text-primary text-sm focus:outline-none focus:ring-1 focus:ring-secondary"/>
                </div>

                <!-- Rol y Especialidad -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="flex flex-col space-y-1">
                        <label class="text-xs text-on-surface font-semibold">ROL ASIGNADO</label>
                        <select name="rol" class="w-full h-11 px-3 rounded-lg bg-surface-container-lowest border border-glass-border text-text-primary text-sm">
                            <option value="jugador" <?php echo $operador->getRol() === 'jugador' ? 'selected' : ''; ?>>Jugador</option>
                            <option value="tirador" <?php echo $operador->getRol() === 'tirador' ? 'selected' : ''; ?>>Tirador</option>
                            <option value="admin" <?php echo $operador->getRol() === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                        </select>
                    </div>

                    <div class="flex flex-col space-y-1">
                        <label class="text-xs text-on-surface font-semibold">ESPECIALIDAD</label>
                        <select name="especialidad" class="w-full h-11 px-3 rounded-lg bg-surface-container-lowest border border-glass-border text-text-primary text-sm">
                            <option value="Asalto" <?php echo $operador->getEspecialidad() === 'Asalto' ? 'selected' : ''; ?>>Asalto</option>
                            <option value="Francotirador" <?php echo $operador->getEspecialidad() === 'Francotirador' ? 'selected' : ''; ?>>Francotirador</option>
                            <option value="Apoyo" <?php echo $operador->getEspecialidad() === 'Apoyo' ? 'selected' : ''; ?>>Apoyo</option>
                            <option value="Médico" <?php echo $operador->getEspecialidad() === 'Médico' ? 'selected' : ''; ?>>Médico</option>
                        </select>
                    </div>
                </div>

                <!-- Botones de Acción -->
                <div class="flex items-center gap-3 pt-4">
                    <button type="submit" class="flex-1 h-11 rounded-lg bg-primary hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2">
                        <span class="material-symbols-outlined text-lg">save</span>
                        <span>Guardar Cambios</span>
                    </button>
                    <a href="/operadores" class="h-11 px-5 rounded-lg bg-surface-container-lowest hover:bg-slate-900 border border-glass-border text-text-secondary text-xs uppercase tracking-wider flex items-center justify-center">
                        Cancelar
                    </a>
                </div>
            </form>

        </div>
    </div>
</main>

</body>
</html>