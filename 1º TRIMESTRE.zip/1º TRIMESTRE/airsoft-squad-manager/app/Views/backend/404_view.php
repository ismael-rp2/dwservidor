<!DOCTYPE html>
<html class="dark" lang="es">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Error 404 - Ruta No Encontrada</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#4edea3",
                        "error": "#ffb4ab",
                        "error-container": "#93000a",
                        "surface": "#0b1326",
                        "surface-container-high": "#222a3d",
                        "surface-container-lowest": "#060e20",
                        "text-primary": "#f8fafc",
                        "text-secondary": "#94a3b8",
                        "outline": "#86948a",
                        "glass-panel": "rgba(30, 41, 59, 0.7)",
                        "glass-border": "rgba(255, 255, 255, 0.1)"
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-surface text-text-primary min-h-screen flex flex-col justify-center items-center px-4 font-['Inter'] selection:bg-error-container selection:text-white">

<div class="relative w-full max-w-lg text-center">
    <!-- Resplandor de alerta -->
    <div class="absolute inset-0 bg-error/10 rounded-full blur-3xl pointer-events-none"></div>

    <!-- Tarjeta de Error Glassmorphism -->
    <div class="relative rounded-2xl bg-surface-container-high/60 backdrop-blur-xl border border-error/30 shadow-2xl p-8 sm:p-12 flex flex-col items-center space-y-6">

        <!-- Icono de Advertencia Táctica -->
        <div class="w-16 h-16 rounded-2xl bg-error-container/40 border border-error/50 flex items-center justify-center text-error animate-pulse">
            <span class="material-symbols-outlined text-3xl">dangerous</span>
        </div>

        <!-- Código y Título -->
        <div class="flex flex-col space-y-2">
            <div class="text-xs uppercase tracking-widest text-error font-mono font-bold">
                [ ANOMALÍA DE RED // ERROR 404 ]
            </div>
            <h1 class="text-3xl sm:text-4xl font-extrabold tracking-tight text-text-primary">
                RUTA NO ENCONTRADA
            </h1>
            <p class="text-sm text-text-secondary max-w-sm mx-auto">
                La coordenada o sector táctico al que intentas acceder no existe o ha sido clasificado fuera de tu rango de visibilidad.
            </p>
        </div>

        <!-- Línea divisoria -->
        <div class="w-full h-px bg-glass-border"></div>

        <!-- Botones de Acción -->
        <div class="flex flex-col sm:flex-row gap-3 w-full pt-2">
            <a href="/operadores" class="flex-1 h-11 rounded-lg bg-primary hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(78,222,163,0.3)]">
                <span class="material-symbols-outlined text-lg">radar</span>
                <span>Volver al Roster</span>
            </a>
            <a href="/login" class="flex-1 h-11 rounded-lg bg-surface-container-lowest hover:bg-slate-900 border border-glass-border text-text-primary font-semibold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2">
                <span class="material-symbols-outlined text-lg">login</span>
                <span>Ir al Login</span>
            </a>
        </div>

        <!-- Código de estado técnico -->
        <div class="text-[11px] text-outline font-mono pt-2">
            STATUS: 404_NOT_FOUND // SQUAD-SECURE NODE
        </div>
    </div>
</div>

</body>
</html>