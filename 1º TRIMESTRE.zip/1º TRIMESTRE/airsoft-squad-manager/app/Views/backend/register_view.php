<!DOCTYPE html>
<html class="dark" lang="es">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Airsoft Squad Manager - Solicitud de Alta</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#4edea3",
                        "secondary": "#4cd7f6",
                        "surface": "#0b1326",
                        "surface-container": "#171f33",
                        "surface-container-high": "#222a3d",
                        "surface-container-lowest": "#060e20",
                        "surface-variant": "#2d3449",
                        "text-primary": "#f8fafc",
                        "text-secondary": "#94a3b8",
                        "on-surface": "#dae2fd",
                        "outline": "#86948a",
                        "outline-variant": "#3c4a42",
                        "primary-container": "#10b981",
                        "on-primary": "#003824",
                        "glass-panel": "rgba(30, 41, 59, 0.7)",
                        "glass-border": "rgba(255, 255, 255, 0.1)"
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-surface text-on-surface min-h-screen relative flex flex-col justify-between selection:bg-primary-container selection:text-on-primary font-['Inter']">

<!-- HEADER -->
<header class="relative z-10 w-full pt-8 pb-4 flex justify-center items-center">
    <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface-container-low backdrop-blur-xl shadow-md border border-glass-border">
        <span class="w-2 h-2 rounded-full bg-primary animate-ping"></span>
        <span class="text-xs uppercase tracking-wider text-primary font-semibold">SECURE AUTHENTICATION GATEWAY</span>
        <span class="text-xs text-on-surface-variant">| STATUS: ACTIVE</span>
    </div>
</header>

<!-- MAIN CONTAINER -->
<main class="relative z-10 w-full flex-1 flex flex-col justify-center items-center px-4 py-6">
    <div class="relative w-full max-w-2xl">

        <!-- Dossier Card -->
        <div class="relative rounded-2xl bg-surface-container-high/60 backdrop-blur-xl border border-glass-border shadow-2xl p-6 sm:p-10 flex flex-col space-y-8 overflow-hidden">

            <!-- Card Header -->
            <div class="flex flex-col space-y-1.5">
                <div class="flex items-center space-x-2">
                    <span class="h-px w-6 bg-primary"></span>
                    <span class="text-xs uppercase tracking-widest text-primary font-bold">AIRSOFT SQUAD MANAGER</span>
                </div>
                <h1 class="text-2xl sm:text-3xl text-text-primary tracking-tight font-bold">
                    SOLICITUD DE ALTA TÁCTICA
                </h1>
                <p class="text-sm text-text-secondary flex items-center gap-2">
                    <span class="material-symbols-outlined text-base text-secondary">terminal</span>
                    <span>REGISTRO DE OPERADOR // EXPEDIENTE DE INCORPORACIÓN</span>
                </p>
            </div>

            <div class="w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>

            <!-- FORMULARIO DE REGISTRO APUNTANDO A /register -->
            <form action="/register" class="flex flex-col space-y-6" method="POST">

                <!-- Grid 2 Columnas: Apodo y Email -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <!-- Apodo / Indicativo -->
                    <div class="flex flex-col space-y-1.5">
                        <label class="text-xs text-on-surface flex items-center justify-between font-semibold" for="apodo">
                                <span class="flex items-center gap-1.5">
                                    <span class="material-symbols-outlined text-base text-primary">badge</span>
                                    <span>APODO / INDICATIVO</span>
                                </span>
                            <span class="text-xs text-outline">REQUERIDO</span>
                        </label>
                        <div class="relative flex items-center">
                            <input class="w-full h-11 px-3.5 pl-10 rounded-lg bg-surface-container-lowest/80 border border-glass-border text-text-primary text-sm focus:outline-none focus:ring-1 focus:ring-primary transition-all" id="apodo" name="apodo" placeholder="ej: Ghost, Soap" required type="text"/>
                            <span class="material-symbols-outlined absolute left-3 text-lg text-outline-variant pointer-events-none">fingerprint</span>
                        </div>
                    </div>

                    <!-- Email Seguro -->
                    <div class="flex flex-col space-y-1.5">
                        <label class="text-xs text-on-surface flex items-center justify-between font-semibold" for="email">
                                <span class="flex items-center gap-1.5">
                                    <span class="material-symbols-outlined text-base text-secondary">alternate_email</span>
                                    <span>EMAIL SEGURO</span>
                                </span>
                            <span class="text-xs text-outline">CANAL MIL</span>
                        </label>
                        <div class="relative flex items-center">
                            <input class="w-full h-11 px-3.5 pl-10 rounded-lg bg-surface-container-lowest/80 border border-glass-border text-text-primary text-sm focus:outline-none focus:ring-1 focus:ring-secondary transition-all" id="email" name="email" placeholder="operador@airsoft.com" required type="email"/>
                            <span class="material-symbols-outlined absolute left-3 text-lg text-outline-variant pointer-events-none">mark_email_read</span>
                        </div>
                    </div>
                </div>

                <!-- Contraseña -->
                <div class="flex flex-col space-y-1.5">
                    <label class="text-xs text-on-surface flex items-center justify-between font-semibold" for="password">
                            <span class="flex items-center gap-1.5">
                                <span class="material-symbols-outlined text-base text-primary">lock_open</span>
                               <span>CONTRASEÑA DE ACCESO</span>
                            </span>
                        <span class="text-xs text-outline uppercase">MÍNIMO 6 CARACTERES</span>
                    </label>
                    <div class="relative flex items-center">
                        <input class="w-full h-11 px-3.5 pl-10 rounded-lg bg-surface-container-lowest/80 border border-glass-border text-text-primary text-sm focus:outline-none focus:ring-1 focus:ring-primary transition-all" id="password" name="password" placeholder="••••••••" required type="password"/>
                        <span class="material-symbols-outlined absolute left-3 text-lg text-outline-variant pointer-events-none">key</span>
                    </div>
                </div>

                <!-- Grid: Rol y Especialidad -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <!-- Rol -->
                    <div class="flex flex-col space-y-1.5">
                        <label class="text-xs text-on-surface flex items-center gap-1.5 font-semibold" for="rol">
                            <span class="material-symbols-outlined text-base text-primary">groups</span>
                            <span>ROL ASIGNADO</span>
                        </label>
                        <div class="relative flex items-center">
                            <select class="w-full h-11 px-3.5 pl-10 pr-9 rounded-lg bg-surface-container-lowest/80 border border-glass-border text-text-primary text-sm appearance-none focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer" id="rol" name="rol" required>
                                <option value="jugador">Jugador / Operador</option>
                                <option value="tirador">Tirador</option>
                                <option value="admin">Administrador</option>
                            </select>
                            <span class="material-symbols-outlined absolute left-3 text-lg text-outline-variant pointer-events-none">military_tech</span>
                            <span class="material-symbols-outlined absolute right-3 text-lg text-outline-variant pointer-events-none">expand_more</span>
                        </div>
                    </div>

                    <!-- Especialidad -->
                    <div class="flex flex-col space-y-1.5">
                        <label class="text-xs text-on-surface flex items-center gap-1.5 font-semibold" for="especialidad">
                            <span class="material-symbols-outlined text-base text-secondary">target</span>
                            <span>ESPECIALIDAD PRIMARIA</span>
                        </label>
                        <div class="relative flex items-center">
                            <select class="w-full h-11 px-3.5 pl-10 pr-9 rounded-lg bg-surface-container-lowest/80 border border-glass-border text-text-primary text-sm appearance-none focus:outline-none focus:ring-1 focus:ring-secondary cursor-pointer" id="especialidad" name="especialidad" required>
                                <option value="Asalto">Asalto / Brecha</option>
                                <option value="Francotirador">Francotirador / Recon</option>
                                <option value="Apoyo">Apoyo / Heavy Gunner</option>
                                <option value="Médico">Médico Táctico</option>
                            </select>
                            <span class="material-symbols-outlined absolute left-3 text-lg text-outline-variant pointer-events-none">swords</span>
                            <span class="material-symbols-outlined absolute right-3 text-lg text-outline-variant pointer-events-none">expand_more</span>
                        </div>
                    </div>
                </div>

                <!-- Botón de Envío -->
                <div class="pt-2">
                    <button class="w-full h-12 rounded-lg bg-primary hover:bg-primary-container text-on-primary font-bold uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(16,185,129,0.25)] flex items-center justify-center gap-2 cursor-pointer" type="submit">
                        <span class="material-symbols-outlined text-xl">how_to_reg</span>
                        <span>AUTORIZAR REGISTRO DE OPERADOR</span>
                    </button>
                </div>
            </form>

            <div class="w-full h-px bg-surface-variant/40"></div>

            <!-- Enlace de vuelta al Login -->
            <div class="flex items-center justify-between pt-1">
                <a class="text-sm text-text-secondary hover:text-text-primary flex items-center gap-2 transition-colors group" href="/login">
                    <span>¿Ya tienes credencial asignada?</span>
                    <span class="text-secondary font-bold group-hover:underline flex items-center">
                            INICIAR SESIÓN
                            <span class="material-symbols-outlined text-base ml-1">login</span>
                        </span>
                </a>
            </div>
        </div>
    </div>
</main>

<!-- FOOTER -->
<footer class="relative z-10 w-full pb-8 pt-4 text-center">
    <div class="text-xs text-on-surface-variant">TACTICAL SQUAD COMMAND • CLASSIFIED CLEARANCE REQUIRED</div>
</footer>
</body>
</html>