<!DOCTYPE html>
<html class="dark" lang="es">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Airsoft Squad Manager - Operadores</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#4edea3",
                        "surface-bright": "#31394d",
                        "on-surface-variant": "#bbcabf",
                        "background-surface": "#1e293b",
                        "surface-variant": "#2d3449",
                        "secondary": "#4cd7f6",
                        "glass-panel": "rgba(30, 41, 59, 0.7)",
                        "on-surface": "#dae2fd",
                        "outline": "#86948a",
                        "glass-border": "rgba(255, 255, 255, 0.1)",
                        "background-base": "#0f172a",
                        "primary-container": "#10b981",
                        "on-primary-fixed": "#002113",
                        "surface-container-high": "#222a3d",
                        "surface-container-lowest": "#060e20",
                        "text-primary": "#f8fafc",
                        "text-secondary": "#94a3b8",
                        "error": "#ffb4ab"
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-background-base text-on-surface font-['Inter'] text-sm min-h-screen selection:bg-primary-container selection:text-on-primary-fixed">

<!-- HEADER -->
<header class="fixed top-0 left-0 w-full z-50 bg-background-base/80 backdrop-blur-xl border-b border-glass-border shadow-[0_4px_20px_rgba(0,0,0,0.4)]">
    <div class="h-20 w-full px-8 flex items-center justify-between gap-4">
        <div class="flex items-center gap-4 flex-shrink-0">
            <div class="flex flex-col">
                <span class="text-lg tracking-wider uppercase text-text-primary font-bold">AIRSOFT SQUAD MANAGER</span>
                <div class="flex items-center gap-1">
                    <span class="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
                    <span class="text-xs uppercase text-text-secondary tracking-widest">TACTICAL HUD V4.2</span>
                </div>
            </div>
        </div>
        <nav class="hidden lg:flex items-center gap-4">
            <a class="px-4 py-2 uppercase tracking-wider transition-all bg-primary-container text-on-primary-fixed font-semibold rounded-lg shadow-[0_0_15px_rgba(16,185,129,0.35)]" href="#">Operadores</a>
            <a class="px-4 py-2 uppercase tracking-wider transition-all bg-surface-container-high text-text-secondary hover:text-text-primary rounded-lg border border-glass-border" href="/logout">Cerrar Sesión</a>
        </nav>
    </div>
</header>

<!-- MAIN CONTENT -->
<main class="w-full pt-28 pb-12 bg-gradient-to-b from-background-base via-surface-container-lowest to-background-surface min-h-screen relative">
    <div class="relative z-10 w-full px-8 max-w-7xl mx-auto flex flex-col gap-8">

        <!-- SECTION HEADER -->
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6 w-full">
            <div class="flex flex-col gap-2">
                <div class="flex items-center gap-3 flex-wrap">
                    <h1 class="text-3xl text-text-primary tracking-tight font-bold">
                        Gestión de Operadores
                    </h1>
                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary-container/20 border border-primary/30 backdrop-blur-md">
                        <span class="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                        <span class="text-xs text-primary tracking-wider uppercase font-semibold">Sistema Activo</span>
                    </div>
                </div>
                <p class="text-sm text-text-secondary max-w-2xl">
                    Supervisión, despliegue y asignación táctica de miembros del escuadrón en tiempo real.
                </p>
            </div>
        </div>

        <!-- OPERATOR ROSTER TABLE PANEL -->
        <div class="w-full rounded-xl bg-glass-panel backdrop-blur-xl border border-glass-border shadow-2xl overflow-hidden flex flex-col">
            <div class="overflow-x-auto w-full">
                <table class="w-full text-left border-collapse min-w-[900px]">
                    <thead>
                    <tr class="border-b border-glass-border bg-surface-container-lowest/50">
                        <th class="py-4 px-6 text-xs uppercase tracking-widest text-text-secondary font-semibold">ID Táctico</th>
                        <th class="py-4 px-6 text-xs uppercase tracking-widest text-text-secondary font-semibold">Apodo / Indicativo</th>
                        <th class="py-4 px-6 text-xs uppercase tracking-widest text-text-secondary font-semibold">Email Seguro</th>
                        <th class="py-4 px-6 text-xs uppercase tracking-widest text-text-secondary font-semibold">Rol Asignado</th>
                        <th class="py-4 px-6 text-xs uppercase tracking-widest text-text-secondary font-semibold">Especialidad Primaria</th>
                        <th class="py-4 px-6 text-xs uppercase tracking-widest text-text-secondary font-semibold text-right">Acciones</th>
                    </tr>
                    </thead>
                    <tbody class="divide-y divide-glass-border">
                    <?php if (empty($operadores)): ?>
                        <tr>
                            <td colspan="6" class="py-12 text-center text-text-secondary">
                                No hay operadores registrados en el escuadrón.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($operadores as $operador): ?>
                            <tr class="hover:bg-surface-variant/40 transition-colors duration-150 group">
                                <!-- ID Táctico -->
                                <td class="py-4 px-6 whitespace-nowrap">
                                            <span class="px-2 py-1 rounded bg-surface-container-high/80 border border-glass-border text-xs text-secondary font-mono">
                                                #OP-0<?php echo htmlspecialchars($operador->getId()); ?>
                                            </span>
                                </td>

                                <!-- Apodo / Indicativo -->
                                <td class="py-4 px-6 whitespace-nowrap">
                                    <div class="flex items-center gap-3">
                                        <div class="relative">
                                            <div class="w-10 h-10 rounded-lg bg-surface-container-high flex items-center justify-center border border-glass-border overflow-hidden">
                                                <span class="material-symbols-outlined text-secondary text-lg">masks</span>
                                            </div>
                                            <span class="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-primary border-2 border-background-base" title="Estado: Listo"></span>
                                        </div>
                                        <div class="flex flex-col">
                                                    <span class="text-base text-text-primary font-bold group-hover:text-primary transition-colors">
                                                        <?php echo htmlspecialchars($operador->getApodo()); ?>
                                                    </span>
                                            <span class="text-xs text-text-secondary">Operador Activo</span>
                                        </div>
                                    </div>
                                </td>

                                <!-- Email Seguro -->
                                <td class="py-4 px-6 whitespace-nowrap text-xs text-on-surface-variant font-mono">
                                    <?php echo htmlspecialchars($operador->getEmail()); ?>
                                </td>

                                <!-- Rol Asignado -->
                                <td class="py-4 px-6 whitespace-nowrap">
                                            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-secondary/15 text-secondary border border-secondary/30 text-xs font-semibold tracking-wide">
                                                <span class="w-1.5 h-1.5 rounded-full bg-secondary"></span>
                                                <?php echo htmlspecialchars($operador->getRol()); ?>
                                            </span>
                                </td>

                                <!-- Especialidad -->
                                <td class="py-4 px-6 whitespace-nowrap">
                                    <div class="inline-flex items-center gap-2 text-text-primary text-xs">
                                        <span class="material-symbols-outlined text-outline text-base">visibility_off</span>
                                        <span><?php echo htmlspecialchars($operador->getEspecialidad()); ?></span>
                                    </div>
                                </td>

                                <!-- Acciones (Editar y Eliminar) -->
                                <td class="py-4 px-6 whitespace-nowrap text-right">
                                    <div class="inline-flex items-center gap-1.5 justify-end">
                                        <!-- Botón Editar -->
                                        <a href="/operadores/editar/<?php echo $operador->getId(); ?>" class="p-2 rounded-lg text-outline hover:text-secondary hover:bg-surface-container-high transition-colors" title="Editar Operador">
                                            <span class="material-symbols-outlined text-lg">edit</span>
                                        </a>

                                        <!-- Botón Eliminar con confirmación JS -->
                                        <a href="/operadores/eliminar/<?php echo $operador->getId(); ?>" onclick="return confirm('¿Estás seguro de dar de baja al operador #OP-0<?php echo $operador->getId(); ?>?');" class="p-2 rounded-lg text-outline hover:text-error hover:bg-error-container/20 transition-colors" title="Dar de baja (Eliminar)">
                                            <span class="material-symbols-outlined text-lg">delete</span>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- TABLE FOOTER -->
            <div class="flex items-center justify-between p-4 bg-surface-container-lowest/60 border-t border-glass-border">
                <div class="text-xs text-text-secondary flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-primary"></span>
                    <span>Total de operadores en base de datos: <span class="font-semibold text-text-primary"><?php echo count($operadores); ?></span></span>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- FOOTER -->
<footer class="w-full bg-surface-container-lowest border-t border-glass-border py-6">
    <div class="w-full px-8 flex items-center justify-center">
        <div class="text-xs text-outline">© 2026 Airsoft Squad Manager. Protocolo Operativo Táctico.</div>
    </div>
</footer>
</body>
</html>