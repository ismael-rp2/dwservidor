<!DOCTYPE html>

<html class="dark" lang="en"><head><meta charset="utf-8"/><meta content="width=device-width, initial-scale=1.0" name="viewport"/><meta content="web_blank" name="shell-type"/><link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/><style>@layer base{html,body{margin:0;padding:0;}body{overscroll-behavior:none;}main>:first-child{margin-top:0!important;}main>:last-child{margin-bottom:0!important;}}::-webkit-scrollbar{display:none;}</style><script src="https://cdn.tailwindcss.com"></script><script id="tailwind-config">tailwind.config={darkMode:"class",theme:{extend:{"colors":{"on-secondary-fixed-variant":"#004e5c","secondary-fixed":"#acedff","on-surface":"#dae2fd","surface-container-high":"#222a3d","primary":"#4edea3","glass-border":"rgba(255, 255, 255, 0.1)","on-tertiary-fixed":"#410005","secondary-fixed-dim":"#4cd7f6","inverse-on-surface":"#283044","tertiary-container":"#fc7c78","error-container":"#93000a","on-tertiary":"#650911","outline":"#86948a","on-tertiary-fixed-variant":"#842225","surface":"#0b1326","primary-fixed-dim":"#4edea3","secondary":"#4cd7f6","text-primary":"#f8fafc","on-primary-fixed-variant":"#005236","on-primary":"#003824","inverse-surface":"#dae2fd","on-surface-variant":"#bbcabf","inverse-primary":"#006c49","surface-container":"#171f33","on-error":"#690005","text-secondary":"#94a3b8","on-primary-container":"#00422b","on-tertiary-container":"#711419","surface-container-lowest":"#060e20","surface-dim":"#0b1326","on-secondary":"#003640","on-secondary-container":"#00424e","surface-variant":"#2d3449","primary-container":"#10b981","surface-tint":"#4edea3","on-background":"#dae2fd","surface-container-low":"#131b2e","on-secondary-fixed":"#001f26","tertiary-fixed":"#ffdad7","background":"#0b1326","glass-panel":"rgba(30, 41, 59, 0.7)","background-surface":"#1e293b","on-primary-fixed":"#002113","surface-bright":"#31394d","primary-fixed":"#6ffbbe","error":"#ffb4ab","tertiary":"#ffb3af","on-error-container":"#ffdad6","tertiary-fixed-dim":"#ffb3af","outline-variant":"#3c4a42","secondary-container":"#03b5d3","surface-container-highest":"#2d3449","background-base":"#0f172a"},"borderRadius":{"DEFAULT":"0.25rem","lg":"0.5rem","xl":"0.75rem","full":"9999px"},"spacing":{"space-lg":"1.5rem","space-sm":"0.5rem","space-xs":"0.25rem","gutter-tablet":"1.5rem","space-md":"1rem","margin-tablet":"1.5rem","space-xl":"2rem","margin":"1rem","gutter":"1rem","gutter-desktop":"1.5rem","margin-desktop":"2rem"},"fontFamily":{"headline-xl":["Inter"],"label-md":["Inter"],"headline-lg":["Inter"],"body-sm":["Inter"],"headline-sm":["Inter"],"headline-lg-mobile":["Inter"],"headline-xl-mobile":["Inter"],"body-lg":["Inter"],"label-sm":["Inter"],"headline-md":["Inter"],"body-md":["Inter"]},"fontSize":{"headline-xl":["36px",{"lineHeight":"44px","letterSpacing":"-0.02em","fontWeight":"700"}],"label-md":["13px",{"lineHeight":"18px","letterSpacing":"0.01em","fontWeight":"500"}],"headline-lg":["30px",{"lineHeight":"38px","letterSpacing":"-0.01em","fontWeight":"700"}],"body-sm":["12px",{"lineHeight":"16px","fontWeight":"400"}],"headline-sm":["18px",{"lineHeight":"24px","fontWeight":"600"}],"headline-lg-mobile":["24px",{"lineHeight":"32px","fontWeight":"700"}],"headline-xl-mobile":["28px",{"lineHeight":"36px","letterSpacing":"-0.01em","fontWeight":"700"}],"body-lg":["16px",{"lineHeight":"24px","fontWeight":"400"}],"label-sm":["11px",{"lineHeight":"16px","letterSpacing":"0.05em","fontWeight":"600"}],"headline-md":["22px",{"lineHeight":"28px","fontWeight":"600"}],"body-md":["14px",{"lineHeight":"20px","fontWeight":"400"}]}}}}</script></head><body class="bg-surface text-on-surface min-h-screen relative flex flex-col justify-between selection:bg-primary-container selection:text-on-primary"><div class="pointer-events-none fixed inset-0 z-0 overflow-hidden"><div class="absolute top-6 left-6 font-label-sm text-label-sm text-outline-variant flex items-center space-x-2 tracking-widest uppercase"><span class="inline-block w-1.5 h-1.5 bg-primary rounded-full animate-pulse"></span><span>SEC-NODE // 0x48A-MIL</span></div><div class="absolute top-6 right-6 font-label-sm text-label-sm text-outline-variant flex items-center space-x-3 tracking-widest uppercase"><span>ENCRYPT // AES-GCM-256</span><div class="w-2 h-2 border-t border-r border-outline-variant"></div></div><div class="absolute bottom-6 left-6 font-label-sm text-label-sm text-outline-variant flex items-center space-x-3 tracking-widest uppercase"><div class="w-2 h-2 border-b border-l border-outline-variant"></div><span>LOC // GRID-REF 8492.11</span></div><div class="absolute bottom-6 right-6 font-label-sm text-label-sm text-outline-variant flex items-center space-x-2 tracking-widest uppercase"><span>SQUAD-OS V2.4.9</span><span class="material-symbols-outlined text-[14px] text-primary">verified_user</span></div><div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(78,222,163,0.03)_0%,transparent_70%)]"></div></div><header class="relative z-10 w-full pt-8 pb-4 flex justify-center items-center"><div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface-container-low backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)]"><span class="w-2 h-2 rounded-full bg-primary animate-ping"></span><span class="font-label-sm text-label-sm uppercase tracking-wider text-primary">SECURE AUTHENTICATION GATEWAY</span><span class="font-label-sm text-label-sm text-on-surface-variant">| STATUS: ACTIVE</span></div></header><main class="relative z-10 w-full flex-1 flex flex-col justify-center items-center px-4"><div class="flex flex-col w-full items-center justify-center py-6 sm:py-10">
        <div class="relative w-full max-w-lg">
            <!-- Atmospheric Ambient Glows behind Card -->
            <div class="absolute -top-16 -left-16 w-64 h-64 bg-primary/10 rounded-full blur-3xl pointer-events-none"></div>
            <div class="absolute -bottom-16 -right-16 w-64 h-64 bg-secondary/10 rounded-full blur-3xl pointer-events-none"></div>
            <!-- Main Glassmorphic Tactical Card -->
            <div class="relative w-full bg-surface-container/70 backdrop-blur-xl rounded-xl shadow-2xl overflow-hidden p-6 sm:p-10 flex flex-col gap-6">
                <!-- Top HUD Decorative Edge & Telemetry Ribbon -->
                <div class="flex items-center justify-between gap-2 pb-4">
                    <div class="flex items-center gap-2">
<span class="relative flex h-2 w-2">
<span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
<span class="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
</span>
                        <span class="font-label-sm text-label-sm uppercase tracking-wider text-primary">CONEXIÓN SEGURA ACTIVA</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="font-label-sm text-label-sm tracking-widest text-on-surface-variant uppercase">TERMINAL MIL-SPEC // NODO v4.2</span>
                        <span class="material-symbols-outlined text-[16px] text-secondary">encrypted</span>
                    </div>
                </div>
                <!-- Tactical Shield / Crosshair Emblem & Titles -->
                <div class="flex flex-col items-center text-center gap-3">
                    <div class="relative flex items-center justify-center w-16 h-16 rounded-xl bg-surface-container-high/80 text-primary shadow-[0_0_25px_rgba(78,222,163,0.18)]">
                        <!-- Crosshair graphic elements inside emblem -->
                        <svg class="absolute inset-0 w-full h-full p-2 text-outline-variant/30" fill="none" stroke="currentColor" stroke-width="2" viewbox="0 0 100 100">
                            <circle cx="50" cy="50" r="42" stroke-dasharray="4 4"></circle>
                            <line stroke="currentColor" stroke-width="3" x1="50" x2="50" y1="5" y2="22"></line>
                            <line stroke="currentColor" stroke-width="3" x1="50" x2="50" y1="78" y2="95"></line>
                            <line stroke="currentColor" stroke-width="3" x1="5" x2="22" y1="50" y2="50"></line>
                            <line stroke="currentColor" stroke-width="3" x1="78" x2="95" y1="50" y2="50"></line>
                        </svg>
                        <span class="material-symbols-outlined text-[32px] text-primary" style="font-variation-settings: 'FILL' 1;">shield</span>
                    </div>
                    <div class="flex flex-col">
                        <h1 class="font-headline-md text-headline-md text-text-primary uppercase tracking-tight">AIRSOFT SQUAD MANAGER</h1>
                        <p class="font-label-md text-label-md text-text-secondary uppercase tracking-widest mt-0.5">ACCESO SEGURO // AUTENTICACIÓN TÁCTICA</p>
                    </div>
                </div>
                <!-- Authentication Form (PHP MVC Compatible) -->
                <form action="/login" class="flex flex-col gap-5 mt-1" method="POST" novalidate="">
                    <!-- Input Group: Email -->
                    <div class="flex flex-col gap-1.5">
                        <div class="flex justify-between items-center">
                            <label class="font-label-md text-label-md text-text-secondary uppercase tracking-wide flex items-center gap-1.5" for="email">
                                <span class="material-symbols-outlined text-[16px] text-primary">badge</span>
                                <span>Email Seguro del Operador</span>
                            </label>
                            <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-widest">ID_AUTH</span>
                        </div>
                        <div class="relative flex items-center">
                            <div class="absolute left-3.5 flex items-center pointer-events-none text-text-secondary">
                                <span class="material-symbols-outlined text-[18px]">alternate_email</span>
                            </div>
                            <input autocomplete="email" class="w-full bg-surface-container-lowest/80 text-text-primary font-body-md text-body-md placeholder:text-text-secondary/50 rounded-lg pl-10 pr-4 py-3 outline-none focus:bg-surface-container-low transition-all duration-200" id="email" name="email" placeholder="operador@squadops.net" required="" type="email"/>
                        </div>
                    </div>
                    <!-- Input Group: Password -->
                    <div class="flex flex-col gap-1.5">
                        <div class="flex justify-between items-center">
                            <label class="font-label-md text-label-md text-text-secondary uppercase tracking-wide flex items-center gap-1.5" for="password">
                                <span class="material-symbols-outlined text-[16px] text-primary">key</span>
                                <span>Contraseña de Acceso</span>
                            </label>
                            <div class="flex items-center gap-1">
                                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span>
                                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span>
                                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span>
                                <span class="w-1.5 h-1.5 rounded-full bg-outline-variant"></span>
                                <span class="font-label-sm text-label-sm text-primary uppercase ml-1">NIVEL 3</span>
                            </div>
                        </div>
                        <div class="relative flex items-center">
                            <div class="absolute left-3.5 flex items-center pointer-events-none text-text-secondary">
                                <span class="material-symbols-outlined text-[18px]">lock</span>
                            </div>
                            <input autocomplete="current-password" class="w-full bg-surface-container-lowest/80 text-text-primary font-body-md text-body-md placeholder:text-text-secondary/50 rounded-lg pl-10 pr-12 py-3 outline-none focus:bg-surface-container-low transition-all duration-200" id="password" name="password" placeholder="••••••••••••" required="" type="password"/>
                            <button aria-label="Alternar visibilidad de contraseña" class="absolute right-3.5 text-text-secondary hover:text-text-primary p-1 focus:outline-none transition-colors" id="togglePassword" type="button">
                                <span class="material-symbols-outlined text-[20px]" id="passwordIcon">visibility</span>
                            </button>
                        </div>
                    </div>
                    <!-- Utilities Row: Remember & Forgot Link -->
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                        <label class="flex items-center gap-2.5 cursor-pointer select-none">
                            <div class="relative flex items-center">
                                <input class="sr-only peer" id="remember_me" name="remember_me" type="checkbox" value="1"/>
                                <div class="w-4 h-4 rounded-sm bg-surface-container-lowest peer-checked:bg-primary-container peer-checked:text-on-primary-container flex items-center justify-center transition-all">
                                    <span class="material-symbols-outlined text-[14px] opacity-0 peer-checked:opacity-100 font-bold">check</span>
                                </div>
                            </div>
                            <span class="font-label-md text-label-md text-on-surface-variant">Recordar en este nodo</span>
                        </label>
                        <a class="font-label-md text-label-md text-secondary hover:text-secondary-fixed transition-colors underline-offset-4 hover:underline text-left sm:text-right" href="/auth/recovery">
                            ¿Olvidó su clave táctica?
                        </a>
                    </div>
                    <!-- Primary Call-to-Action -->
                    <button class="w-full mt-2 py-3.5 px-6 rounded-lg bg-primary-container text-on-primary font-headline-sm text-headline-sm uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-[0_0_20px_rgba(16,185,129,0.35)] hover:bg-primary transition-all duration-200 active:scale-[0.99] cursor-pointer" type="submit">
                        <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">lock_open</span>
                        <span>Autorizar Acceso al Sistema</span>
                    </button>
                    <!-- Secondary Security Authentication Modules -->
                    <div class="relative flex items-center justify-center my-1">
                        <div class="w-full bg-surface-variant/40 h-px"></div>
                        <span class="absolute bg-surface-container px-3 font-label-sm text-label-sm text-outline tracking-wider uppercase">VÍAS COMPLEMENTARIAS</span>
                    </div>
                    <!-- FIDO2 / YubiKey Hardware Token Auth -->
                    <button class="w-full py-2.5 px-4 rounded-lg bg-surface-container-high/60 hover:bg-surface-container-high text-on-surface font-label-md text-label-md uppercase tracking-wider flex items-center justify-between transition-all duration-200 group cursor-pointer" type="button">
                        <div class="flex items-center gap-2.5">
                            <span class="material-symbols-outlined text-[18px] text-secondary group-hover:text-primary transition-colors">token</span>
                            <span>Acceso Hardware FIDO2 / YubiKey</span>
                        </div>
                        <span class="font-label-sm text-label-sm text-outline-variant group-hover:text-on-surface transition-colors">SCAN READY</span>
                    </button>
                </form>
                <!-- Bottom Registration Link -->
                <div class="flex items-center justify-center pt-2">
                    <p class="font-body-md text-body-md text-text-secondary text-center">
                        ¿No tienes credencial asignada?
                        <a class="text-primary hover:text-primary-fixed-dim font-headline-sm text-headline-sm uppercase tracking-wider ml-1 inline-flex items-center gap-1 transition-colors" href="/register">
                            <span>Solicitar Alta</span>
                            <span class="material-symbols-outlined text-[14px]">arrow_forward</span>
                        </a>
                    </p>
                </div>
                <!-- Tactical Footer Protocol Marker -->
                <div class="rounded-lg bg-surface-container-lowest/60 p-3 flex items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-[16px] text-tertiary">warning</span>
                        <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-tight">ACCESO RESTRINGIDO // CODEX-884</span>
                    </div>
                    <span class="font-label-sm text-label-sm text-outline uppercase tracking-widest">AES-256 GCM</span>
                </div>
            </div>
        </div>
    </div>
    <script>
        (function() {
            const toggleBtn = document.getElementById('togglePassword');
            const pwdInput = document.getElementById('password');
            const pwdIcon = document.getElementById('passwordIcon');

            if (toggleBtn && pwdInput && pwdIcon) {
                toggleBtn.addEventListener('click', function() {
                    const isPassword = pwdInput.type === 'password';
                    pwdInput.type = isPassword ? 'text' : 'password';
                    pwdIcon.textContent = isPassword ? 'visibility_off' : 'visibility';
                });
            }
        })();
    </script></main><footer class="relative z-10 w-full pb-8 pt-4 flex flex-col sm:flex-row justify-center items-center gap-4 text-center"><div class="font-label-sm text-label-sm text-on-surface-variant flex items-center gap-2"><span>TACTICAL SQUAD COMMAND</span><span>•</span><span>CLASSIFIED CLEARANCE REQUIRED</span><span>•</span><span class="text-outline">SESSION_TIMEOUT: 120S</span></div></footer></body></html>