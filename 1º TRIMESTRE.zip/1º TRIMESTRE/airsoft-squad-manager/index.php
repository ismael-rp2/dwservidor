<?php
// 1. Cargar todas las librerías de Composer
require_once __DIR__ . '/vendor/autoload.php';

use Phroute\Phroute\RouteCollector;
use Phroute\Phroute\Dispatcher;
use Phroute\Phroute\Exception\HttpRouteNotFoundException;
use Phroute\Phroute\Exception\HttpMethodNotAllowedException;

// 2. Cargar las variables de entorno de forma segura
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// 3. Inicializar el recolector de rutas
$router = new RouteCollector();

// ==========================================
// ZONA DE RUTAS (El mapa de la aplicación)
// ==========================================

$router->get('/', function() {
    return "<h1>¡Bienvenido a Airsoft Squad Manager!</h1><p>El motor de rutas está funcionando perfectamente.</p>";
});

// Aquí añadiremos luego las rutas de /operador y /arsenal

// ==========================================
// ZONA DE DESPACHO (No tocar)
// ==========================================
$dispatcher = new Dispatcher($router->getData());

try {
    $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $response = $dispatcher->dispatch($_SERVER['REQUEST_METHOD'], $url);
    echo $response;
} catch (HttpRouteNotFoundException $e) {
    http_response_code(404);
    echo "<h1>Error 404</h1><p>Operador, te has perdido. Esta ruta no existe.</p>";
} catch (HttpMethodNotAllowedException $e) {
    http_response_code(405);
    echo "<h1>Error 405</h1><p>Método HTTP no permitido para esta acción.</p>";
}