<?php
// 1. Cargar todas las librerías de Composer
require_once __DIR__ . '/vendor/autoload.php';

use Phroute\Phroute\RouteCollector;
use Phroute\Phroute\Dispatcher;
use Phroute\Phroute\Exception\HttpRouteNotFoundException;
use Phroute\Phroute\Exception\HttpMethodNotAllowedException;

// 2. Cargar las variables de entorno de forma segura
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// 3. Inicializar el recolector de rutas
$router = new RouteCollector();

// ==========================================
// ZONA DE RUTAS (El mapa de la aplicación)
// ==========================================

$router->get('/', function() {
    return "<h1>¡Bienvenido a Airsoft Squad Manager!</h1><p>El motor de rutas está funcionando perfectamente.</p>";
});

// Operadores
$router->post('/operadores', ['Ismael\Airsoft\Controllers\OperadorController', 'store']);
$router->get('/operadores', ['Ismael\Airsoft\Controllers\OperadorController', 'index']);

// Rutas de Autenticación
$router->get('/login', ['Ismael\Airsoft\Controllers\AuthController', 'showLogin']);
$router->post('/login', ['Ismael\Airsoft\Controllers\AuthController', 'login']);
$router->get('/register', ['Ismael\Airsoft\Controllers\AuthController', 'showRegister']);
$router->post('/register', ['Ismael\Airsoft\Controllers\AuthController', 'register']);
$router->get('/logout', ['Ismael\Airsoft\Controllers\AuthController', 'logout']);

// ==========================================
// ZONA DE DESPACHO (Gestión de Errores 404 / 405)
// ==========================================
$dispatcher = new Dispatcher($router->getData());

try {
    $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $response = $dispatcher->dispatch($_SERVER['REQUEST_METHOD'], $url);
    echo $response;
} catch (HttpRouteNotFoundException $e) {
    http_response_code(404);
    require_once __DIR__ . '/app/Views/backend/404_view.php';
} catch (HttpMethodNotAllowedException $e) {
    http_response_code(405);
    echo "<h1>Error 405</h1><p>Método HTTP no permitido para esta acción.</p>";
}

// Rutas para Editar Operadores
$router->get('/operadores/editar/{id}', ['Ismael\Airsoft\Controllers\OperadorController', 'edit']);
$router->post('/operadores/editar/{id}', ['Ismael\Airsoft\Controllers\OperadorController', 'update']);
$router->get('/operadores/eliminar/{id}', ['Ismael\Airsoft\Controllers\OperadorController', 'delete']);