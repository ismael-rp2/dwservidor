USE airsoft;

CREATE TABLE operadores (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            apodo VARCHAR(100) NOT NULL,
                            email VARCHAR(100) NOT NULL UNIQUE,
                            password VARCHAR(255) NOT NULL,
                            rol VARCHAR(50) DEFAULT 'jugador',
                            especialidad VARCHAR(100)
);